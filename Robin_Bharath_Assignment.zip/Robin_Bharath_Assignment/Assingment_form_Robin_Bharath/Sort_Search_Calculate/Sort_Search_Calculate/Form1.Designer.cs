﻿namespace Sort_Search_Calculate
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSort = new System.Windows.Forms.Button();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.btnSearch = new System.Windows.Forms.Button();
            this.listBoxSortFolder = new System.Windows.Forms.ListBox();
            this.listBoxSortFiles = new System.Windows.Forms.ListBox();
            this.listBoxCalcFolder = new System.Windows.Forms.ListBox();
            this.listBoxCalcLines = new System.Windows.Forms.ListBox();
            this.listBoxSearch = new System.Windows.Forms.ListBox();
            this.textBoxSearch = new System.Windows.Forms.TextBox();
            this.lblBanner = new System.Windows.Forms.Label();
            this.lblSortFolder = new System.Windows.Forms.Label();
            this.lblSortFiles = new System.Windows.Forms.Label();
            this.lblCalcFolder = new System.Windows.Forms.Label();
            this.lblCalcLines = new System.Windows.Forms.Label();
            this.lblNotify = new System.Windows.Forms.Label();
            this.lblSearchMsg = new System.Windows.Forms.Label();
            this.FBD = new System.Windows.Forms.FolderBrowserDialog();
            this.lblSearch = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnSort
            // 
            this.btnSort.BackColor = System.Drawing.Color.Olive;
            this.btnSort.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSort.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.btnSort.Location = new System.Drawing.Point(33, 52);
            this.btnSort.Name = "btnSort";
            this.btnSort.Size = new System.Drawing.Size(253, 32);
            this.btnSort.TabIndex = 0;
            this.btnSort.Text = "Start Sorting Here!";
            this.btnSort.UseVisualStyleBackColor = false;
            this.btnSort.Click += new System.EventHandler(this.btnSort_Click);
            // 
            // btnCalculate
            // 
            this.btnCalculate.BackColor = System.Drawing.Color.Olive;
            this.btnCalculate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalculate.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.btnCalculate.Location = new System.Drawing.Point(345, 52);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(253, 32);
            this.btnCalculate.TabIndex = 1;
            this.btnCalculate.Text = "Start Calculate Here!";
            this.btnCalculate.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.btnCalculate.UseVisualStyleBackColor = false;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Maroon;
            this.button3.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.button3.Location = new System.Drawing.Point(619, 53);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 32);
            this.button3.TabIndex = 2;
            this.button3.Text = "Exit";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.Color.Green;
            this.btnSearch.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnSearch.Location = new System.Drawing.Point(357, 398);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 29);
            this.btnSearch.TabIndex = 3;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.Visible = false;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // listBoxSortFolder
            // 
            this.listBoxSortFolder.FormattingEnabled = true;
            this.listBoxSortFolder.Location = new System.Drawing.Point(79, 171);
            this.listBoxSortFolder.Name = "listBoxSortFolder";
            this.listBoxSortFolder.Size = new System.Drawing.Size(228, 95);
            this.listBoxSortFolder.TabIndex = 4;
            this.listBoxSortFolder.Visible = false;
            this.listBoxSortFolder.SelectedIndexChanged += new System.EventHandler(this.listBoxSortFolder_SelectedIndexChanged);
            // 
            // listBoxSortFiles
            // 
            this.listBoxSortFiles.FormattingEnabled = true;
            this.listBoxSortFiles.Location = new System.Drawing.Point(79, 303);
            this.listBoxSortFiles.Name = "listBoxSortFiles";
            this.listBoxSortFiles.Size = new System.Drawing.Size(228, 95);
            this.listBoxSortFiles.TabIndex = 5;
            this.listBoxSortFiles.Visible = false;
            // 
            // listBoxCalcFolder
            // 
            this.listBoxCalcFolder.FormattingEnabled = true;
            this.listBoxCalcFolder.Location = new System.Drawing.Point(451, 167);
            this.listBoxCalcFolder.Name = "listBoxCalcFolder";
            this.listBoxCalcFolder.Size = new System.Drawing.Size(261, 95);
            this.listBoxCalcFolder.TabIndex = 6;
            this.listBoxCalcFolder.Visible = false;
            this.listBoxCalcFolder.SelectedIndexChanged += new System.EventHandler(this.listBoxCalcFolder_SelectedIndexChanged);
            // 
            // listBoxCalcLines
            // 
            this.listBoxCalcLines.FormattingEnabled = true;
            this.listBoxCalcLines.Location = new System.Drawing.Point(451, 303);
            this.listBoxCalcLines.Name = "listBoxCalcLines";
            this.listBoxCalcLines.Size = new System.Drawing.Size(261, 95);
            this.listBoxCalcLines.TabIndex = 7;
            this.listBoxCalcLines.Visible = false;
            // 
            // listBoxSearch
            // 
            this.listBoxSearch.FormattingEnabled = true;
            this.listBoxSearch.Location = new System.Drawing.Point(208, 482);
            this.listBoxSearch.Name = "listBoxSearch";
            this.listBoxSearch.Size = new System.Drawing.Size(224, 56);
            this.listBoxSearch.TabIndex = 8;
            this.listBoxSearch.Visible = false;
            // 
            // textBoxSearch
            // 
            this.textBoxSearch.Location = new System.Drawing.Point(250, 403);
            this.textBoxSearch.Name = "textBoxSearch";
            this.textBoxSearch.Size = new System.Drawing.Size(100, 20);
            this.textBoxSearch.TabIndex = 9;
            this.textBoxSearch.Visible = false;
            // 
            // lblBanner
            // 
            this.lblBanner.BackColor = System.Drawing.SystemColors.HotTrack;
            this.lblBanner.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBanner.ForeColor = System.Drawing.SystemColors.Info;
            this.lblBanner.Location = new System.Drawing.Point(-2, -1);
            this.lblBanner.Name = "lblBanner";
            this.lblBanner.Size = new System.Drawing.Size(749, 51);
            this.lblBanner.TabIndex = 10;
            this.lblBanner.Text = "Sort && Search / Calculator";
            this.lblBanner.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblSortFolder
            // 
            this.lblSortFolder.Location = new System.Drawing.Point(76, 139);
            this.lblSortFolder.Name = "lblSortFolder";
            this.lblSortFolder.Size = new System.Drawing.Size(101, 31);
            this.lblSortFolder.TabIndex = 11;
            this.lblSortFolder.Text = "lblSortFolder";
            this.lblSortFolder.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblSortFolder.Visible = false;
            // 
            // lblSortFiles
            // 
            this.lblSortFiles.Location = new System.Drawing.Point(76, 269);
            this.lblSortFiles.Name = "lblSortFiles";
            this.lblSortFiles.Size = new System.Drawing.Size(121, 34);
            this.lblSortFiles.TabIndex = 12;
            this.lblSortFiles.Text = "lblSortFiles";
            this.lblSortFiles.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblSortFiles.Visible = false;
            // 
            // lblCalcFolder
            // 
            this.lblCalcFolder.Location = new System.Drawing.Point(448, 136);
            this.lblCalcFolder.Name = "lblCalcFolder";
            this.lblCalcFolder.Size = new System.Drawing.Size(105, 31);
            this.lblCalcFolder.TabIndex = 13;
            this.lblCalcFolder.Text = "lblCalcFolder";
            this.lblCalcFolder.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblCalcFolder.Visible = false;
            // 
            // lblCalcLines
            // 
            this.lblCalcLines.Location = new System.Drawing.Point(448, 271);
            this.lblCalcLines.Name = "lblCalcLines";
            this.lblCalcLines.Size = new System.Drawing.Size(121, 31);
            this.lblCalcLines.TabIndex = 14;
            this.lblCalcLines.Text = "lblCalcLines";
            this.lblCalcLines.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblCalcLines.Visible = false;
            // 
            // lblNotify
            // 
            this.lblNotify.Font = new System.Drawing.Font("Rockwell", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNotify.ForeColor = System.Drawing.Color.Green;
            this.lblNotify.Location = new System.Drawing.Point(2, 88);
            this.lblNotify.Name = "lblNotify";
            this.lblNotify.Size = new System.Drawing.Size(745, 48);
            this.lblNotify.TabIndex = 15;
            this.lblNotify.Text = "lblNotify";
            this.lblNotify.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblNotify.Visible = false;
            // 
            // lblSearchMsg
            // 
            this.lblSearchMsg.Font = new System.Drawing.Font("Rockwell", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearchMsg.ForeColor = System.Drawing.Color.Green;
            this.lblSearchMsg.Location = new System.Drawing.Point(172, 436);
            this.lblSearchMsg.Name = "lblSearchMsg";
            this.lblSearchMsg.Size = new System.Drawing.Size(318, 43);
            this.lblSearchMsg.TabIndex = 16;
            this.lblSearchMsg.Text = "lblSearchMsg";
            this.lblSearchMsg.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblSearchMsg.Visible = false;
            // 
            // lblSearch
            // 
            this.lblSearch.Location = new System.Drawing.Point(130, 398);
            this.lblSearch.Name = "lblSearch";
            this.lblSearch.Size = new System.Drawing.Size(114, 31);
            this.lblSearch.TabIndex = 17;
            this.lblSearch.Text = "lblSearch";
            this.lblSearch.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblSearch.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.ClientSize = new System.Drawing.Size(747, 534);
            this.Controls.Add(this.lblSearch);
            this.Controls.Add(this.lblSearchMsg);
            this.Controls.Add(this.lblNotify);
            this.Controls.Add(this.lblCalcLines);
            this.Controls.Add(this.lblCalcFolder);
            this.Controls.Add(this.lblSortFiles);
            this.Controls.Add(this.lblSortFolder);
            this.Controls.Add(this.lblBanner);
            this.Controls.Add(this.textBoxSearch);
            this.Controls.Add(this.listBoxSearch);
            this.Controls.Add(this.listBoxCalcLines);
            this.Controls.Add(this.listBoxCalcFolder);
            this.Controls.Add(this.listBoxSortFiles);
            this.Controls.Add(this.listBoxSortFolder);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.btnSort);
            this.Name = "Form1";
            this.Text = "Assignment-Robin&Bharath";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSort;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.ListBox listBoxSortFolder;
        private System.Windows.Forms.ListBox listBoxSortFiles;
        private System.Windows.Forms.ListBox listBoxCalcFolder;
        private System.Windows.Forms.ListBox listBoxCalcLines;
        private System.Windows.Forms.ListBox listBoxSearch;
        private System.Windows.Forms.TextBox textBoxSearch;
        private System.Windows.Forms.Label lblBanner;
        private System.Windows.Forms.Label lblSortFolder;
        private System.Windows.Forms.Label lblSortFiles;
        private System.Windows.Forms.Label lblCalcFolder;
        private System.Windows.Forms.Label lblCalcLines;
        private System.Windows.Forms.Label lblNotify;
        private System.Windows.Forms.Label lblSearchMsg;
        private System.Windows.Forms.FolderBrowserDialog FBD;
        private System.Windows.Forms.Label lblSearch;
    }
}

