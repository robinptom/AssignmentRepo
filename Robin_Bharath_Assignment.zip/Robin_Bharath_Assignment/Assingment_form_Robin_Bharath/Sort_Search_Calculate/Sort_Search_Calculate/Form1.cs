﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Globalization;

namespace Sort_Search_Calculate
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
//Functions for Calculations//
        
            //To identify the operator present in the each expresion from the calc files.
        public static string GetOperationFormExpression(string expression)
        {
            if (expression.Contains("+"))
            {
                return "+";
            }
            if (expression.Contains("-"))
            {
                return "-";
            }
            if (expression.Contains("*"))
            {
                return "*";
            }
            if (expression.Contains("/"))
            {
                return "/";
            }
            if (expression.Contains("%"))
            {
                return "%";
            }
            if (expression.Contains("^"))
            {
                return "^";
            }
            return "nothing";
        }

        // To split(seperate) the single string expression in to operands and operator.
        
        public static string[] GetSplitStringBasedOnOperation(string expression, char operation)
        {
            return expression.Split(operation);
        }

        //To calculate the result of the expression. (using the splited values)
        public static float GetResult(float number1, float number2, char operation)
        {
            switch (operation)
            {
                case '+':
                    return number1 + number2;
                //break;
                case '-':
                    return number1 - number2;
                //break;
                case '*':
                    return number1 * number2;
                //break;
                case '/':
                    return number1 / number2;
                //break;
                case '%':
                    return number1 % number2;
                //break;
                case '^':
                    return (float)Math.Pow(number1, number2);
                //break;
                default:
                    return 0;
            }
        }

        private void btnSort_Click(object sender, EventArgs e)
        {
            lblCalcFolder.Hide();
            listBoxCalcFolder.Hide();
            lblCalcLines.Hide();
            listBoxCalcLines.Hide();

            if (FBD.ShowDialog() == DialogResult.OK)
            {


                // Creating an instance of the FolderBrowserDialog//    
                DirectoryInfo folder = new DirectoryInfo(FBD.SelectedPath);
                // Get all .txt files//
                FileInfo[] allTxtFiles = folder.GetFiles("*.txt");

                // Creating an index number to search the text files by the folder//
                int dirIndex = listBoxSortFolder.Items.Count;
                // Insert the selected folder in to listbox at specified index//
                listBoxSortFolder.Items.Insert(dirIndex, FBD.SelectedPath);
                listBoxSortFolder.Show();
                lblSortFolder.Text = "List of Selected Folders";
                lblSortFolder.Show();

                string contents;
                string[] words;
                List<string> listOfFiles = new List<string>();

                foreach (FileInfo txtFile in allTxtFiles)
                {
                    contents = File.ReadAllText(txtFile.FullName);
                    listOfFiles.Add(txtFile.Name);
                    words = contents.Split('\n', '\r', ' ','.',',');
                    Array.Sort(words);
                    int wordCount = words.Length;

                    string currWord;
                    string nextWord;
                    int repeatCounter = 1;
                    List<string> sortedWords;
                    sortedWords = new List<string>();

                    for (int i = 0; i < wordCount; i++)
                    {
                        currWord = words[i];
                        Search.AddKeyWord(currWord, txtFile.Name);//storing words and filenames in myKeyWordList//
                        if (i < wordCount - 1)
                        {
                            nextWord = words[i + 1];
                            if (currWord == nextWord)
                            {
                                repeatCounter++;
                                continue;
                            }
                        }
                        if (repeatCounter > 1)
                        {
                            sortedWords.Add(currWord + "," + repeatCounter);
                        }
                        else
                        {
                            sortedWords.Add(currWord);
                        }
                        repeatCounter = 1;
                    }

                    sortedWords.ToArray();
                    File.WriteAllText(Path.Combine(FBD.SelectedPath, "sorted" + txtFile.Name), string.Join(Environment.NewLine, sortedWords));
                    listBoxSortFiles.Items.Add(txtFile.Name);
                    lblSortFiles.Show();
                    lblSortFiles.Text = "List of Text Files:";
                    listBoxSortFiles.Show();

                }
                lblNotify.Text = " SORTING COMPLETED! SELECT ANOTHER FOLDER ";
                lblNotify.Show();
                lblSearch.Show();
                textBoxSearch.Show();
                btnSearch.Show();
                Search.AddToDirectory(dirIndex, listOfFiles);
                //MessageBox.Show("Sorting Completed");

            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            listBoxSearch.Items.Clear();

            List<string> resultFiles = Search.SearchKeyWord(textBoxSearch.Text);
            lblSearchMsg.Text = "' " + textBoxSearch.Text + " '" + " is found " + resultFiles.Count + " times";
            if (resultFiles.Count > 0)
            {
                listBoxSearch.Show();
                lblSearchMsg.Show();
                lblSearchMsg.Text = lblSearchMsg.Text + " and appeared in the below files";
            }
            foreach (string content in resultFiles) // Loop through List with foreach
            {
                listBoxSearch.Items.Add(content);
            }
        }
        //calculation section
        private void btnCalculate_Click(object sender, EventArgs e)
        {
            listBoxSortFolder.Hide();
            listBoxSortFiles.Hide();
            lblSortFiles.Hide();
            lblSortFolder.Hide();
            lblSearch.Hide();
            lblSearchMsg.Hide();
            textBoxSearch.Hide();
            btnSearch.Hide();
            listBoxSearch.Hide();


            if (FBD.ShowDialog() == DialogResult.OK)
            {
                DirectoryInfo folder = new DirectoryInfo(FBD.SelectedPath);
                FileInfo[] allCalcFiles = folder.GetFiles("*.calc");
                int index = listBoxCalcFolder.Items.Count;
                listBoxCalcFolder.Items.Insert(index, FBD.SelectedPath);

                //DateTime now = DateTime.Now;
                lblCalcFolder.Text = "Selected Folder";
                lblCalcFolder.Show();
                //listBox1.Items.Insert(index, now);
                listBoxCalcFolder.Show();
                List<string> finalResult = new List<string>();
                List<string> resultStrings = new List<string>();
                List<string> listOfCalcFiles = new List<string>();
                foreach (FileInfo calcFile in allCalcFiles)
                {
                    string content;
                    content = File.ReadAllText(calcFile.FullName);
                    listOfCalcFiles.Add(calcFile.Name);
                    string[] calculations;
                    calculations = content.Split('\n');

                    foreach (string calculation in calculations)
                    {
                        string currExpr;
                        currExpr = calculation;
                        Search.AddcalcKeyWord(currExpr, calcFile.Name);
                        listBoxCalcLines.Items.Add(calculation);
                        lblCalcLines.Text = "Available Expresiions:";
                        listBoxCalcLines.Show();
                        lblCalcLines.Show();
                        string operation = GetOperationFormExpression(calculation.Trim());
                        if (operation == "nothing")
                        {
                            Console.WriteLine("Uh-oh ! Found no operators in this line:" + calculation.Trim());
                            //Console.WriteLine(calculation.Trim());
                        }
                        else
                        {
                            string[] splitLine = GetSplitStringBasedOnOperation(calculation.Trim(), operation.ToCharArray()[0]);
                            if (splitLine.Length != 2)
                            {
                                Console.WriteLine("Uh-oh ! Found more or less than 2 numbers in this line:" + calculation.Trim());
                                //Console.WriteLine(calculation.Trim());
                            }
                            else
                            {
                                float number1 = float.Parse(splitLine[0], CultureInfo.InvariantCulture.NumberFormat);
                                float number2 = float.Parse(splitLine[1], CultureInfo.InvariantCulture.NumberFormat);
                                float result = (float)Math.Round(GetResult(number1, number2, operation.ToCharArray()[0]), 2);
                                string resultString = number1 + " " + operation + " " + number2 + " = " + result;
                                resultStrings.Add(resultString);
                            }
                        }
                    }
                    finalResult = resultStrings;

                }
                string n = string.Format("{0:yyyy-MM-dd_hh-mm-ss-tt}.answ", DateTime.Now);
                File.WriteAllText(Path.Combine(FBD.SelectedPath, n), string.Join(Environment.NewLine, finalResult));
                Search.AddToCalcDirectory(index, listOfCalcFiles);
                lblNotify.Show();
                lblNotify.Text = "Calculation Completed: ";
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        //To display the files of a selected folder
        private void listBoxSortFolder_SelectedIndexChanged(object sender, EventArgs e)
        {
            List<string> filesInDirectory = Search.GetFiles(listBoxSortFolder.SelectedIndex);
            listBoxSortFiles.Items.Clear();

            if (filesInDirectory.Count > 0)
            {
                foreach (string fileName in filesInDirectory)
                {
                    listBoxSortFiles.Items.Add(fileName);
                }

            }
            else
            {
                listBoxSortFiles.Items.Insert(0, "No Items");
            }
        }
        //Display the contents of a selected folder in the calculation.
        private void listBoxCalcFolder_SelectedIndexChanged(object sender, EventArgs e)
        {
            List<string> calcFilesInDirectory = Search.GetcalcFiles(listBoxCalcFolder.SelectedIndex);
            listBoxCalcLines.Items.Clear();
            if (calcFilesInDirectory.Count > 0)
            {
                foreach (string fileName in calcFilesInDirectory)
                {
                    listBoxCalcLines.Items.Add(fileName);
                }

            }
            else
            {
                listBoxCalcLines.Items.Insert(0, "No Items");
            }
        }
    }
    }
    //Class for Search Functions.
    public class Search
    {
        //Creating an instance of the Keyword object.  
        static List<KeyWord> myKeyWordList = new List<KeyWord>();
        static List<KeyWord> calcKeyWordList = new List<KeyWord>();

        //Creating a Dictionary object to store the list of Directories with an index number. 
        static Dictionary<int, List<string>> searchDirectory = new Dictionary<int, List<string>>();
        static Dictionary<int, List<string>> calcDirectory = new Dictionary<int, List<string>>();

        //List of strings to store each file name in the searchDirectory
        static List<string> sortedFileNames = new List<string>();
        static List<string> processedCalcFileNames = new List<string>();

        //Function for returning the file names which contains the search Keyword. 

        public static List<string> GetFiles(int directoryIndex)
        {
            List<string> filesInThisDirectory = new List<string>();
            foreach (KeyValuePair<int, List<string>> entry in searchDirectory)
            {
                if (entry.Key == directoryIndex)
                {
                    filesInThisDirectory = entry.Value;
                }
            }
            return filesInThisDirectory;
        }

        public static void AddToDirectory(int directoryIndex, List<string> files)
        {
            searchDirectory.Add(directoryIndex, files);
            foreach (string fileName in files)
            {
                sortedFileNames.Add(fileName);
            }
        }

        //Function for adding each word and thier filename in to the myKeywordList

        public static void AddKeyWord(string keyword, string filename)
        {
            myKeyWordList.Add(new KeyWord { Value = keyword, FileName = filename });
        }

        //Function for return a value to the searchButton

        public static List<string> SearchKeyWord(string searchkeyword)
        {
            List<string> searchFiles = new List<string>();
            foreach (KeyWord KEYWORD in myKeyWordList)
            {
                if (KEYWORD.Value == searchkeyword)
                {
                    searchFiles.Add(KEYWORD.FileName);
                }
            }
            return searchFiles;
        }


        //Functions for calculator to store processed filename and Directory//


        public static List<string> GetcalcFiles(int directoryIndex)
        {
            List<string> calcFilesInThisDirectory = new List<string>();
            foreach (KeyValuePair<int, List<string>> entry in calcDirectory)
            {
                if (entry.Key == directoryIndex)
                {
                    calcFilesInThisDirectory = entry.Value;
                }
            }
            return calcFilesInThisDirectory;
        }
       

        public static void AddToCalcDirectory(int directoryIndex, List<string> files)
        {
            calcDirectory.Add(directoryIndex, files);
            foreach (string fileName in files)
            {
                processedCalcFileNames.Add(fileName);
            }
        }
        
        public static void AddcalcKeyWord(string keyword, string filename)
        {
            calcKeyWordList.Add(new KeyWord { Value = keyword, FileName = filename });
        }
        
    }
    //Defining a class KeyWord.
    public class KeyWord
    {
        public string Value { get; set; }
        public string FileName { get; set; }
    }

